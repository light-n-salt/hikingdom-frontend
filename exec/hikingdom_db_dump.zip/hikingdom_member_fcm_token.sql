create table member_fcm_token
(
    id          bigint auto_increment
        primary key,
    created_at  datetime(6)     null,
    modified_at datetime(6)     null,
    body        varchar(500)    null,
    member_id   bigint unsigned null,
    constraint FK1t32tfi2x0x2xl8te76jm3q2u
        foreign key (member_id) references member (id)
);

INSERT INTO hikingdom.member_fcm_token (id, created_at, modified_at, body, member_id) VALUES (31, '2023-05-19 01:49:48.258827', '2023-05-19 01:49:48.258827', 'dwQR1DjkSXC-ArdNzUeAp-:APA91bHv8rTMbYk4pgdbsC1YVknKXDAlBrvSjsJTubWbjO9uyF87O42STd9ACi3sQij-8b4DT-b6MFgnlP7FNU3leYV_Pj5yOa0MEQuHmD3GBIQrpQESS_SNc_8TYuS_vKetXfnMyRNl', 1);
INSERT INTO hikingdom.member_fcm_token (id, created_at, modified_at, body, member_id) VALUES (32, '2023-05-19 02:14:30.305748', '2023-05-19 02:14:30.305748', 'dwQR1DjkSXC-ArdNzUeAp-:APA91bHv8rTMbYk4pgdbsC1YVknKXDAlBrvSjsJTubWbjO9uyF87O42STd9ACi3sQij-8b4DT-b6MFgnlP7FNU3leYV_Pj5yOa0MEQuHmD3GBIQrpQESS_SNc_8TYuS_vKetXfnMyRNl', 6);
INSERT INTO hikingdom.member_fcm_token (id, created_at, modified_at, body, member_id) VALUES (33, '2023-05-19 11:50:10.220515', '2023-05-19 11:50:10.220515', 'f7CUW1rqSlSXkDw0HQUeh1:APA91bFziWsl0oIGHwtn5F1nYzcCrXraqZ-gBmiiYa9W4jOSLGvkIvA8GyJNHaWZOlaNhXKgYtujJC-1GB2KWixPMTIjnPwaTrGwK-Xct97C-Re5N0186f1Rb1uo_eJk7sPP8CeTG2q2', 10);
INSERT INTO hikingdom.member_fcm_token (id, created_at, modified_at, body, member_id) VALUES (34, '2023-05-19 11:54:01.207291', '2023-05-19 11:54:01.207291', 'c-1_cGZDT7y-UJIqAuzrjw:APA91bGFVLV846zfpdjJJ9IcWH9ut8R-Rkp-x69cE8tho94rP3YjZaD8thO2mLmARIOlb58dwoSqnINUEhhOHwfH7A8v8RGw_BwimGpwAZ2GokEQHVIfgRN08rFpKSe9E6rqDqUGSIQ2', 10);
