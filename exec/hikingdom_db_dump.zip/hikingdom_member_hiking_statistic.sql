create table member_hiking_statistic
(
    id                   bigint unsigned          not null
        primary key,
    total_alt            int unsigned default '0' not null,
    total_distance       int unsigned default '0' not null,
    total_duration       int unsigned default '0' not null,
    total_hiking_count   int unsigned default '0' not null,
    total_mountain_count int unsigned default '0' not null,
    constraint FKs81d67mvfrevmpfofssst2u15
        foreign key (id) references member (id)
);

INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (1, 113864, 1631122, 31407, 176, 94);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (2, 20800, 721190, 648900, 94, 88);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (3, 12480, 404197, 363600, 39, 30);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (4, 823, 12673, 547, 3, 3);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (6, 13238, 178120, 4809, 15, 10);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (7, 1698, 25346, 1102, 6, 6);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (8, 660, 15961, 3258, 4, 0);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (9, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (10, 2620, 44682, 11799, 19, 8);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (11, 80, 80, 80, 9, 9);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (12, 2598, 26546, 2101, 9, 8);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (13, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (14, 12639, 208773, 3086, 13, 12);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (15, 2501, 39100, 1660, 9, 8);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (16, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (17, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (18, 0, 0, 0, 0, 0);
