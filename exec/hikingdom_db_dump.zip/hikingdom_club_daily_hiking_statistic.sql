create table club_daily_hiking_statistic
(
    id                   bigint unsigned auto_increment
        primary key,
    date                 datetime(6)              not null,
    participation_rate   double       default 0   not null,
    total_alt            int unsigned default '0' not null,
    total_distance       int unsigned default '0' not null,
    total_duration       int unsigned default '0' not null,
    total_hiking_count   int unsigned default '0' not null,
    total_mountain_count int unsigned default '0' not null,
    club_id              bigint unsigned          not null
);

