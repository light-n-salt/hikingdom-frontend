create table mountain_daily_info
(
    id          bigint unsigned auto_increment
        primary key,
    set_date    date            null,
    mountain_id bigint unsigned not null
);

INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (1, '2023-05-08', 14);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (2, '2023-05-08', 1);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (12, '2023-05-09', 1);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (13, '2023-05-09', 2);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (14, '2023-05-09', 12);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (15, '2023-05-10', 3);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (16, '2023-05-10', 7);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (17, '2023-05-10', 19);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (18, '2023-05-11', 8);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (19, '2023-05-11', 9);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (20, '2023-05-11', 10);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (21, '2023-05-12', 7);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (22, '2023-05-12', 11);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (23, '2023-05-12', 17);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (24, '2023-05-13', 5);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (25, '2023-05-13', 18);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (26, '2023-05-13', 19);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (27, '2023-05-14', 1);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (28, '2023-05-14', 4);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (29, '2023-05-14', 8);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (30, '2023-05-15', 14);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (31, '2023-05-15', 20);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (32, '2023-05-15', 24);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (33, '2023-05-16', 8);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (34, '2023-05-16', 16);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (35, '2023-05-16', 29);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (36, '2023-05-17', 20);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (37, '2023-05-17', 23);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (38, '2023-05-17', 32);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (45, '2023-05-18', 42);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (46, '2023-05-18', 43);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (47, '2023-05-18', 44);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (48, '2023-05-19', 42);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (49, '2023-05-19', 43);
INSERT INTO hikingdom.mountain_daily_info (id, set_date, mountain_id) VALUES (50, '2023-05-19', 44);
