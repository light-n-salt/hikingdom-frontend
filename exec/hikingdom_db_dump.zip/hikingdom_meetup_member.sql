create table meetup_member
(
    id          bigint unsigned auto_increment
        primary key,
    created_at  datetime(6)          null,
    modified_at datetime(6)          null,
    meetup_id   bigint unsigned      not null,
    member_id   bigint unsigned      not null,
    is_withdraw tinyint(1) default 0 null,
    withdraw_at datetime(6)          null
);

INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (1, '2023-05-04 10:10:22.879079', '2023-05-04 10:10:22.879079', 1, 1, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (2, '2023-05-04 10:15:05.043935', '2023-05-04 10:15:05.043935', 2, 1, 1, '2023-05-10 13:39:22.617577');
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (33, '2023-05-10 11:31:08.681233', '2023-05-10 11:31:08.681233', 3, 1, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (34, '2023-05-10 11:32:28.987389', '2023-05-10 11:32:28.987389', 4, 1, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (35, '2023-05-10 11:32:57.652078', '2023-05-10 11:32:57.652078', 5, 1, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (36, '2023-05-10 11:33:59.876797', '2023-05-10 11:33:59.876797', 6, 1, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (37, '2023-05-10 11:34:44.533812', '2023-05-10 11:34:44.533812', 7, 1, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (38, '2023-05-10 14:28:57.398246', '2023-05-10 14:28:57.398246', 8, 1, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (39, '2023-05-10 16:15:52.237613', '2023-05-10 16:15:52.237613', 9, 10, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (40, '2023-05-11 10:15:23', '2023-05-11 10:15:24', 1, 2, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (41, '2023-05-11 10:15:24', '2023-05-11 10:15:25', 1, 3, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (42, '2023-05-11 10:15:26', '2023-05-11 10:15:27', 1, 4, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (44, '2023-05-11 10:15:29', '2023-05-11 10:15:31', 1, 7, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (46, '2023-05-11 10:15:44', '2023-05-11 10:15:45', 1, 9, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (47, '2023-05-11 10:15:46', '2023-05-11 10:15:47', 1, 10, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (49, '2023-05-11 13:08:48.050338', '2023-05-11 13:08:48.050338', 10, 10, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (50, '2023-05-14 17:07:03.040000', '2023-05-14 17:07:03.040000', 11, 6, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (51, '2023-05-15 16:44:52.115000', '2023-05-15 16:44:52.115000', 12, 10, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (52, '2023-05-15 23:05:50.117045', '2023-05-15 23:05:50.117045', 13, 14, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (53, '2023-05-15 23:06:38.040586', '2023-05-15 23:06:38.040586', 14, 14, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (54, '2023-05-16 09:59:20.218262', '2023-05-16 09:59:20.218262', 10, 1, 1, '2023-05-16 00:59:20');
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (55, '2023-05-16 09:59:21.294000', '2023-05-16 09:59:21.294000', 10, 1, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (56, '2023-05-16 11:11:01.816203', '2023-05-16 11:11:01.816203', 15, 12, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (57, '2023-05-16 13:28:45.271000', '2023-05-16 13:28:45.271000', 13, 6, 1, '2023-05-16 04:28:46');
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (58, '2023-05-16 15:46:20.210778', '2023-05-16 15:46:20.210778', 16, 6, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (59, '2023-05-17 08:59:56.110789', '2023-05-17 08:59:56.110789', 8, 6, 1, '2023-05-17 04:52:23');
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (60, '2023-05-17 09:31:33.507628', '2023-05-17 09:31:33.507628', 1, 8, 1, '2023-05-17 00:32:05');
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (61, '2023-05-17 10:32:21.052418', '2023-05-17 10:32:21.052418', 1, 6, 1, '2023-05-17 05:40:30');
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (62, '2023-05-17 13:42:32.264193', '2023-05-17 13:42:32.264193', 17, 6, 1, '2023-05-17 04:50:31');
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (63, '2023-05-17 13:51:10.781871', '2023-05-17 13:51:10.781871', 18, 6, 1, '2023-05-17 04:51:12');
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (64, '2023-05-17 13:52:05.809892', '2023-05-17 13:52:05.809892', 14, 6, 1, '2023-05-17 04:52:06');
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (65, '2023-05-17 13:52:25.287914', '2023-05-17 13:52:25.287914', 8, 6, 1, '2023-05-17 04:52:29');
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (72, '2023-05-17 14:49:22.728442', '2023-05-17 14:49:22.728442', 8, 6, 1, '2023-05-17 05:50:25');
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (75, '2023-05-17 14:55:08.593398', '2023-05-17 14:55:08.593398', 4, 6, 1, '2023-05-17 05:55:10');
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (76, '2023-05-17 14:55:38.931773', '2023-05-17 14:55:38.931773', 14, 6, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (77, '2023-05-17 17:29:47.462900', '2023-05-17 17:29:47.462900', 1, 8, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (78, '2023-05-17 19:05:21.028924', '2023-05-17 19:05:21.028924', 19, 1, 1, '2023-05-18 01:10:39');
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (79, '2023-05-18 10:20:27.819931', '2023-05-18 10:20:27.819931', 20, 1, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (80, '2023-05-18 10:51:44.034653', '2023-05-18 10:51:44.034653', 20, 10, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (81, '2023-05-18 13:02:39.539833', '2023-05-18 13:02:39.539833', 21, 1, 1, '2023-05-18 04:02:44');
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (82, '2023-05-18 13:02:47.785842', '2023-05-18 13:02:47.785842', 21, 1, 1, '2023-05-18 04:04:41');
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (83, '2023-05-18 13:12:20.872425', '2023-05-18 13:12:20.872425', 22, 1, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (84, '2023-05-18 13:32:11.156468', '2023-05-18 13:32:11.156468', 22, 18, 1, '2023-05-18 04:37:29');
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (85, '2023-05-18 13:53:31.383410', '2023-05-18 13:53:31.383410', 23, 12, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (86, '2023-05-18 14:00:17.754200', '2023-05-18 14:00:17.754200', 24, 10, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (87, '2023-05-18 16:05:44.848470', '2023-05-18 16:05:44.848470', 25, 10, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (88, '2023-05-18 16:06:20.614501', '2023-05-18 16:06:20.614501', 25, 1, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (89, '2023-05-18 16:11:20.487786', '2023-05-18 16:11:20.487786', 24, 6, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (90, '2023-05-18 16:12:57', '2023-05-18 16:12:59', 20, 6, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (91, '2023-05-18 16:13:52', '2023-05-18 16:13:53', 20, 14, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (93, '2023-05-15 16:44:52.115080', '2023-05-15 16:44:52.115080', 12, 1, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (94, '2023-05-14 17:07:03.040000', '2023-05-14 17:07:03.040402', 11, 1, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (95, '2023-05-16 13:28:45.271752', '2023-05-16 13:28:45.271752', 13, 1, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (96, '2023-05-18 20:41:58.876922', '2023-05-18 20:41:58.876922', 25, 6, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (97, '2023-05-18 22:19:55', '2023-05-18 22:19:57', 1, 6, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (98, '2023-05-18 22:28:07.408805', '2023-05-18 22:28:07.408805', 26, 1, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (99, '2023-05-19 00:42:45.540048', '2023-05-19 00:42:45.540048', 27, 1, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (100, '2023-05-19 01:35:35.546633', '2023-05-19 01:35:35.546633', 28, 12, 0, null);
INSERT INTO hikingdom.meetup_member (id, created_at, modified_at, meetup_id, member_id, is_withdraw, withdraw_at) VALUES (101, '2023-05-19 01:40:01.418725', '2023-05-19 01:40:01.418725', 28, 16, 0, null);
