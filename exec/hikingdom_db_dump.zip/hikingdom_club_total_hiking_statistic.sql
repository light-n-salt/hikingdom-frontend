create table club_total_hiking_statistic
(
    id                   bigint                   not null
        primary key,
    participation_rate   double       default 0   not null,
    total_alt            int unsigned default '0' not null,
    total_distance       int unsigned default '0' not null,
    total_duration       int unsigned default '0' not null,
    total_hiking_count   int unsigned default '0' not null,
    total_mountain_count int unsigned default '0' not null
);

INSERT INTO hikingdom.club_total_hiking_statistic (id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (1, 0, 33128, 70900, 10830, 21, 21);
INSERT INTO hikingdom.club_total_hiking_statistic (id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (2, 0, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_total_hiking_statistic (id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (3, 0, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_total_hiking_statistic (id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (5, 0, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_total_hiking_statistic (id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (6, 0, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_total_hiking_statistic (id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (7, 0, 0, 0, 0, 0, 0);
