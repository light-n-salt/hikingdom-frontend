create table member_report
(
    id               bigint unsigned auto_increment
        primary key,
    reported_type    varchar(255)    not null,
    reported_at      datetime(6)     not null,
    reported_content varchar(255)    not null,
    reported_id      bigint unsigned not null,
    reporter_id      bigint unsigned not null
);

INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (1, 'MEMBER', '2023-05-12 17:00:11.291100', '빛과소금', 1, 6);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (2, 'ALBUM', '2023-05-16 22:26:48.497280', '62', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (3, 'REVIEW', '2023-05-16 22:31:13.596741', '21', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (4, 'REVIEW', '2023-05-17 10:32:30.404141', '25', 6, 6);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (5, 'REVIEW', '2023-05-18 10:11:01.434347', '24', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (6, 'REVIEW', '2023-05-18 10:11:01.910555', '24', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (7, 'REVIEW', '2023-05-18 10:11:04.960646', '24', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (8, 'REVIEW', '2023-05-18 10:11:05.105831', '24', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (9, 'REVIEW', '2023-05-18 10:11:05.278884', '24', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (10, 'REVIEW', '2023-05-18 10:11:05.451867', '24', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (11, 'REVIEW', '2023-05-18 10:11:05.604682', '24', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (12, 'REVIEW', '2023-05-18 10:11:05.770667', '24', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (13, 'REVIEW', '2023-05-18 10:11:05.935645', '24', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (14, 'REVIEW', '2023-05-18 10:11:06.077541', '24', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (15, 'REVIEW', '2023-05-18 10:11:06.239219', '24', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (16, 'REVIEW', '2023-05-18 10:11:06.404172', '24', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (17, 'REVIEW', '2023-05-18 10:11:06.627057', '24', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (18, 'REVIEW', '2023-05-18 10:11:06.741560', '24', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (19, 'REVIEW', '2023-05-18 10:11:06.910161', '24', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (20, 'REVIEW', '2023-05-18 13:14:14.349842', '37', 1, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (21, 'REVIEW', '2023-05-18 13:14:15.222930', '37', 1, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (22, 'REVIEW', '2023-05-18 13:14:15.377240', '37', 1, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (23, 'REVIEW', '2023-05-18 13:14:15.542111', '37', 1, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (24, 'REVIEW', '2023-05-18 13:14:15.699275', '37', 1, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (25, 'REVIEW', '2023-05-18 13:14:15.828577', '37', 1, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (26, 'REVIEW', '2023-05-18 13:14:15.972968', '37', 1, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (27, 'REVIEW', '2023-05-18 13:14:16.137547', '37', 1, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (28, 'ALBUM', '2023-05-18 13:19:17.170907', '53', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (29, 'ALBUM', '2023-05-18 13:19:20.594057', '50', 6, 1);
INSERT INTO hikingdom.member_report (id, reported_type, reported_at, reported_content, reported_id, reporter_id) VALUES (30, 'MEMBER', '2023-05-18 13:21:45.488116', '겁쟁이병호씨', 10, 1);
