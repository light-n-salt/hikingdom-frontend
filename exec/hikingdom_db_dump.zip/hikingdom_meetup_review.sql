create table meetup_review
(
    id          bigint unsigned auto_increment
        primary key,
    created_at  datetime(6)          null,
    modified_at datetime(6)          null,
    content     varchar(1024)        not null,
    deleted_at  datetime(6)          null,
    is_deleted  tinyint(1) default 0 not null,
    is_reported tinyint(1) default 0 not null,
    club_id     bigint unsigned      not null,
    meetup_id   bigint unsigned      not null,
    member_id   bigint unsigned      not null
);

INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (1, '2023-05-09 13:49:33.873729', '2023-05-09 13:49:33.873729', '짱ㅉ아', '2023-05-09 15:26:51.962263', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (2, '2023-05-09 13:49:35.833596', '2023-05-09 13:49:35.833596', '짱ㅉ아', '2023-05-09 15:26:54.300275', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (3, '2023-05-09 13:49:42.575420', '2023-05-09 13:49:42.575420', '짱짱이다!!!', '2023-05-09 15:26:54.862673', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (4, '2023-05-09 13:49:45.214909', '2023-05-09 13:49:45.214909', '짱짱이다!!!', '2023-05-09 15:26:55.209512', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (5, '2023-05-09 13:50:53.817017', '2023-05-09 13:50:53.817017', '대박', '2023-05-09 15:26:55.448767', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (6, '2023-05-09 13:50:55.562525', '2023-05-09 13:50:55.562525', '대박', '2023-05-09 15:26:55.634842', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (7, '2023-05-09 13:50:56.275737', '2023-05-09 13:50:56.275737', '대박', '2023-05-09 15:26:55.785282', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (8, '2023-05-09 13:58:26.298175', '2023-05-09 13:58:26.298175', 'ㄴㅇㄹ', '2023-05-09 15:26:55.918485', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (9, '2023-05-09 13:58:27.148312', '2023-05-09 13:58:27.148312', 'ㄴㅇㄹ', '2023-05-09 15:26:56.077938', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (10, '2023-05-09 14:20:53.592766', '2023-05-09 14:20:53.592766', 'ㄴㅇㄹ', '2023-05-09 15:26:56.232262', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (11, '2023-05-09 14:33:40.922517', '2023-05-09 14:33:40.922517', 'sdf', '2023-05-09 15:26:56.370822', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (12, '2023-05-09 14:49:44.784420', '2023-05-09 14:49:44.784420', '후기', '2023-05-09 15:26:57.972487', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (13, '2023-05-09 14:50:59.340030', '2023-05-09 14:50:59.340030', 'ㄴㅇ', '2023-05-09 15:26:58.454630', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (14, '2023-05-09 14:51:33.679899', '2023-05-09 14:51:33.679899', 'ㄴㅇ', '2023-05-09 15:26:58.800658', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (15, '2023-05-09 14:51:40.021032', '2023-05-09 14:51:40.021032', '지금마지막', '2023-05-09 15:26:59.138749', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (16, '2023-05-09 14:53:44.766103', '2023-05-09 14:53:44.766103', 'ㄴㅇㄹㄴㅇ', '2023-05-09 15:26:59.313153', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (17, '2023-05-09 14:53:54.231610', '2023-05-09 14:53:54.231610', 'ㄴㅇㄹ', '2023-05-09 15:26:59.477338', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (18, '2023-05-09 15:30:41.347662', '2023-05-09 15:30:41.347662', '후기동록~', '2023-05-10 13:02:23.442384', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (19, '2023-05-10 11:09:15.198754', '2023-05-10 11:09:15.198754', '후기후기ㅁㄴㅇㄹ', null, 0, 0, 1, 1, 1);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (20, '2023-05-10 11:09:21.820146', '2023-05-10 11:09:21.820146', '후기남깁니당', '2023-05-10 11:09:22.926538', 1, 0, 1, 1, 1);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (21, '2023-05-10 13:02:27.875822', '2023-05-10 13:02:27.875822', 'gnrlemdfhr~', '2023-05-17 10:32:00.291444', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (22, '2023-05-10 14:53:52.088737', '2023-05-10 14:53:52.088737', '하잉', '2023-05-18 16:24:48.687291', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (23, '2023-05-10 14:54:00.753070', '2023-05-10 14:54:00.753070', '공쥬 등장', null, 0, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (24, '2023-05-10 18:01:28.004853', '2023-05-10 18:01:28.004853', '귀요미 등장', null, 0, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (25, '2023-05-17 10:32:05.457601', '2023-05-17 10:32:05.457601', 'ds', '2023-05-18 16:24:51.127949', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (26, '2023-05-17 10:32:08.102457', '2023-05-17 10:32:08.102457', 'sdf', '2023-05-18 16:24:51.867924', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (27, '2023-05-17 12:55:32.809958', '2023-05-17 12:55:32.809958', '어다러', '2023-05-18 22:31:35.754042', 1, 0, 1, 1, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (28, '2023-05-17 19:05:35.359018', '2023-05-17 19:05:35.359018', '후기를 입력하자!', '2023-05-18 01:10:39', 1, 0, 1, 19, 1);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (29, '2023-05-18 00:18:35.992229', '2023-05-18 00:18:35.992229', '후기를 가기도 전에 할 수 있을까?', null, 0, 0, 1, 8, 1);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (30, '2023-05-18 00:18:37.966905', '2023-05-18 00:18:37.966905', '되넹', null, 0, 0, 1, 8, 1);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (31, '2023-05-18 00:18:56.799081', '2023-05-18 00:18:56.799081', '내가 나를 신고할 수도 있어...', null, 0, 0, 1, 8, 1);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (32, '2023-05-18 00:19:22.648045', '2023-05-18 00:19:22.648045', '날짜랑 시간이 안 뜬당', null, 0, 0, 1, 8, 1);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (37, '2023-05-18 13:13:27.430191', '2023-05-18 13:13:27.430191', '시작시간도 안됐는데 후기가 써지네요..', null, 0, 0, 1, 22, 1);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (38, '2023-05-18 16:14:46.842945', '2023-05-18 16:14:46.842945', '너무 재밌었어효!!', null, 0, 0, 1, 20, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (39, '2023-05-18 16:26:19.541530', '2023-05-18 16:26:19.541530', 'dd', null, 0, 0, 1, 20, 10);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (40, '2023-05-18 22:47:23.539655', '2023-05-18 22:47:23.539655', '후기입니다', '2023-05-18 22:47:27.043952', 1, 0, 1, 11, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (41, '2023-05-18 22:57:00.918337', '2023-05-18 22:57:00.918337', '아무도 안와서 슬펐다', null, 0, 0, 1, 25, 10);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (42, '2023-05-19 02:23:46.108937', '2023-05-19 02:23:46.108937', '후기입니다', null, 0, 0, 1, 11, 6);
INSERT INTO hikingdom.meetup_review (id, created_at, modified_at, content, deleted_at, is_deleted, is_reported, club_id, meetup_id, member_id) VALUES (43, '2023-05-19 10:55:29.723690', '2023-05-19 10:55:29.723690', '후기입니다!', null, 0, 0, 1, 11, 6);
