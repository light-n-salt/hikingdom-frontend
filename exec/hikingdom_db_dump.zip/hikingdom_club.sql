create table club
(
    id                 bigint unsigned auto_increment
        primary key,
    created_at         datetime(6)              null,
    modified_at        datetime(6)              null,
    deleted_at         datetime(6)              null,
    description        varchar(512)             null,
    is_deleted         tinyint(1)   default 0   not null,
    name               varchar(20)              not null,
    total_member_count int unsigned default '1' not null,
    dong_code          varchar(10)              not null,
    host_id            bigint unsigned          not null
);

INSERT INTO hikingdom.club (id, created_at, modified_at, deleted_at, description, is_deleted, name, total_member_count, dong_code, host_id, total_mountain_count, total_meetup_count, total_asset_count, score) VALUES (1, '2023-05-04 09:05:46.303810', '2023-05-19 03:45:17.773203', null, '마리아~ 산타마리아~!!', 0, '산타마리아', 7, '1168000000', 1, 9, 10, 11, 797);
INSERT INTO hikingdom.club (id, created_at, modified_at, deleted_at, description, is_deleted, name, total_member_count, dong_code, host_id, total_mountain_count, total_meetup_count, total_asset_count, score) VALUES (2, '2023-05-04 09:38:02.440693', '2023-05-04 09:38:02.440693', null, '등산하실 서울 1반 싸피인 모여라!!', 0, '싸피 8기 1반', 1, '1168000000', 2, 3, 3, 3, 122);
INSERT INTO hikingdom.club (id, created_at, modified_at, deleted_at, description, is_deleted, name, total_member_count, dong_code, host_id, total_mountain_count, total_meetup_count, total_asset_count, score) VALUES (3, '2023-05-04 09:44:48.344584', '2023-05-04 09:44:48.344584', null, '전국 싸피 8기 모여라!!!', 0, '싸피 8기 전국캠퍼스 등산', 4, '0000000000', 3, 5, 14, 7, 543);
INSERT INTO hikingdom.club (id, created_at, modified_at, deleted_at, description, is_deleted, name, total_member_count, dong_code, host_id, total_mountain_count, total_meetup_count, total_asset_count, score) VALUES (5, '2023-05-10 15:31:45.142837', '2023-05-10 15:31:45.142837', null, '밥머건', 0, '병호와 아이들', 1, '1168000000', 10, 4, 4, 4, 223);
INSERT INTO hikingdom.club (id, created_at, modified_at, deleted_at, description, is_deleted, name, total_member_count, dong_code, host_id, total_mountain_count, total_meetup_count, total_asset_count, score) VALUES (6, '2023-05-12 14:50:20.744216', '2023-05-19 03:35:27.856392', null, '산을 오르는 뾰로롱한 모임', 0, '산사람', 3, '1168000000', 12, 8, 10, 7, 612);
INSERT INTO hikingdom.club (id, created_at, modified_at, deleted_at, description, is_deleted, name, total_member_count, dong_code, host_id, total_mountain_count, total_meetup_count, total_asset_count, score) VALUES (7, '2023-05-18 12:22:43.564325', '2023-05-18 12:22:43.564325', null, '모임이에요~~~', 0, '한마음산악회', 1, '1174000000', 17, 4, 5, 3, 143);
