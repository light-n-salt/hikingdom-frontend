create table BATCH_JOB_EXECUTION_SEQ
(
    ID         bigint not null,
    UNIQUE_KEY char   not null,
    constraint UNIQUE_KEY_UN
        unique (UNIQUE_KEY)
);

INSERT INTO hikingdom.BATCH_JOB_EXECUTION_SEQ (ID, UNIQUE_KEY) VALUES (45, '0');
