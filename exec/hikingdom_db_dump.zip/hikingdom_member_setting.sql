create table member_setting
(
    id          bigint unsigned not null
        primary key,
    created_at  datetime(6)     null,
    modified_at datetime(6)     null,
    constraint FK1uek7qpagt9g7b0yaj5ojeush
        foreign key (id) references member (id)
);

