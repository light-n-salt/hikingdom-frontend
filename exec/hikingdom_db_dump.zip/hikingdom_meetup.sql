create table meetup
(
    id          bigint unsigned auto_increment
        primary key,
    created_at  datetime(6)          null,
    modified_at datetime(6)          null,
    deleted_at  datetime(6)          null,
    description varchar(512)         null,
    is_deleted  tinyint(1) default 0 not null,
    name        varchar(50)          not null,
    start_at    datetime(6)          not null,
    club_id     bigint unsigned      not null,
    host_id     bigint unsigned      not null,
    mountain_id bigint unsigned      not null
);

INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (1, '2023-05-04 10:10:22.844261', '2023-05-04 10:10:22.844261', null, '관악산 연주대 찍으러 가실분 다같이 산타!!', 0, '다같이 관악산 산타!!', '2023-05-17 20:00:00', 1, 1, 10);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (2, '2023-05-04 10:15:05.040733', '2023-05-04 10:15:05.040733', '2023-05-10 13:39:22.622788', '관악산에서 UCC 촬영을 위한 산타!!', 1, 'UCC 촬영 목적 관악산 산타!!', '2023-05-14 14:00:00', 1, 1, 10);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (3, '2023-05-10 11:31:08.640853', '2023-05-10 11:31:08.640853', null, '관악산에서 UCC 촬영을 위한 산타!!', 0, 'UCC 촬영 목적 관악산 또 다시 산타!!', '2023-05-10 11:00:00', 1, 1, 10);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (4, '2023-05-10 11:32:28.984325', '2023-05-10 11:32:28.984325', null, '관악산에서 연주대 인증하기 산타!', 0, '다같이 관악산 또 산타!!', '2023-05-17 20:00:00', 1, 1, 10);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (5, '2023-05-10 11:32:57.649542', '2023-05-10 11:32:57.649542', null, '관악산에서 여유롭게 산책을 위한 산타!', 0, '다같이 관악산 또또 산타!!', '2023-05-10 14:00:00', 1, 1, 10);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (6, '2023-05-10 11:33:59.874512', '2023-05-10 11:33:59.874512', null, '마천대 찍고 정상 인증하기 산타~!!', 0, '다같이 대둔산 산타!!', '2023-05-13 09:00:00', 1, 1, 20);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (7, '2023-05-10 11:34:44.531326', '2023-05-10 11:34:44.531326', null, '정상찍고 막걸리 한잔~~ 하러 산타!!', 0, '다같이 계룡산 산타!!', '2023-05-14 09:00:00', 1, 1, 7);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (8, '2023-05-10 14:28:57.395924', '2023-05-10 14:28:57.395924', null, 'UCC를 위해 관악산을 등반해볼까????', 0, '관악산 등반하자!!!', '2023-05-26 10:28:00', 1, 1, 10);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (9, '2023-05-10 16:15:52.226300', '2023-05-10 16:15:52.226300', null, '같이 산타용', 0, '산타자잉', '2023-05-19 15:56:00', 5, 10, 2);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (10, '2023-05-11 13:08:48.039004', '2023-05-11 13:08:48.039004', null, '가리산 완등 인증까지 하실분! 같이해욥!!', 0, '가리산 등반하실분!', '2023-05-12 15:08:00', 1, 10, 1);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (11, '2023-05-14 17:07:02.992757', '2023-05-14 17:07:02.992757', null, '얏호가보자 다들', 0, '얏호', '2023-05-15 20:09:00', 1, 6, 2);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (12, '2023-05-15 16:44:52.080746', '2023-05-15 16:44:52.080746', null, '도봉산 신선대 찍으러 가실분 다같이 산타!!', 0, '도봉산 산타!!', '2023-05-17 20:00:00', 1, 10, 27);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (13, '2023-05-15 23:05:50.105149', '2023-05-15 23:05:50.105149', null, '대둔산 마천대 찍고 점심 같이 드실 분분!!', 0, '새벽에 대둔산 완등하실분~!!', '2023-05-17 20:00:00', 1, 14, 20);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (14, '2023-05-15 23:06:38.037838', '2023-05-17 23:06:38.037838', null, '계룡산 주변 트래킹하고 막걸리 드실 분!', 0, '오후에 계룡산 가볍게 트래킹 가실 분', '2023-05-17 20:00:00', 1, 14, 7);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (15, '2023-05-16 11:11:01.808597', '2023-05-17 11:11:01.808597', null, '일정', 0, ' 나는야일정', '2023-05-10 13:02:00', 6, 12, 10);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (16, '2023-05-16 15:46:20.171496', '2023-05-17 15:46:20.171496', null, 'ㄴㅇㄹ', 0, 'ddd', '2023-06-02 19:49:00', 1, 6, 5);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (17, '2023-05-17 13:42:32.254449', '2023-05-17 13:42:32.254449', '2023-05-17 04:50:31', 'ㅇㄴㄴㅁㄴㅇㄹ', 1, 'ㅇㅇㅇㅇㅇㅇ', '2023-05-18 13:42:00', 1, 6, 3);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (18, '2023-05-17 13:51:10.779992', '2023-05-17 13:51:10.779992', '2023-05-17 04:51:12', 'dd', 1, 'ffffffffff', '2023-05-20 13:54:00', 1, 6, 1);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (19, '2023-05-17 19:05:21.023223', '2023-05-17 19:05:21.023223', '2023-05-18 01:10:39', 'ㅎㅎㅎㅎ
아니 근데
아니아니', 1, 'ㅎㅎㄹ', '2023-05-18 22:50:00', 1, 1, 5);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (20, '2023-05-18 10:20:27.807471', '2023-05-18 10:20:27.807471', null, '가볍게 관악산 가실 모임원들 구해욥!', 0, '관악산 등반', '2023-05-18 11:20:00', 1, 1, 10);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (21, '2023-05-18 13:02:39.528560', '2023-05-18 13:02:39.528560', '2023-05-18 04:04:41', '지리산이 없다고?
지리산이 없다고!!!!', 1, '지리산 종주', '2023-05-25 14:00:00', 1, 1, 38);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (22, '2023-05-18 13:12:20.870422', '2023-05-18 13:12:20.870422', null, '14시에 가즈아~~', 0, '14시에 산타기', '2023-05-18 14:00:00', 1, 1, 4);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (23, '2023-05-18 13:53:31.381718', '2023-05-18 13:53:31.381718', null, 'ㅇ', 0, 'sdfsdf', '2023-05-31 13:57:00', 6, 12, 10);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (24, '2023-05-18 14:00:17.752609', '2023-05-18 14:00:17.752609', null, '즐겁게 가지산 산타요르~~', 0, '요르요르 가지산 산타요르', '2023-05-20 18:58:00', 1, 10, 4);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (25, '2023-05-18 16:05:44.838527', '2023-05-18 16:05:44.838527', null, '하하호호 줄거운 야간 산행', 0, '야간산행', '2023-05-18 22:05:00', 1, 10, 45);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (26, '2023-05-18 22:28:07.398386', '2023-05-18 22:28:07.398386', null, '배봉산 정상까지!', 0, '배봉산 정복', '2023-05-19 13:30:00', 1, 1, 46);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (27, '2023-05-19 00:42:45.529562', '2023-05-19 00:42:45.529562', null, '응봉근린공원 전망대 가자~~', 0, '응봉산 가자!!!', '2023-05-19 09:42:00', 1, 1, 47);
INSERT INTO hikingdom.meetup (id, created_at, modified_at, deleted_at, description, is_deleted, name, start_at, club_id, host_id, mountain_id) VALUES (28, '2023-05-19 01:35:35.525117', '2023-05-19 01:35:35.525117', null, '하이', 0, '안녕안녕', '2023-05-19 02:03:00', 6, 12, 1);
