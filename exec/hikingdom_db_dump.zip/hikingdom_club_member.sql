create table club_member
(
    id          bigint unsigned auto_increment
        primary key,
    created_at  datetime(6)          null,
    modified_at datetime(6)          null,
    is_withdraw tinyint(1) default 0 null,
    withdraw_at datetime(6)          null,
    club_id     bigint unsigned      null,
    member_id   bigint unsigned      null,
    constraint FKf6tl19ih8acrmheidn4xos2tx
        foreign key (club_id) references club (id),
    constraint FKj63e8ol485xl5sbwfocuyjmm2
        foreign key (member_id) references member (id)
);

INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (1, '2023-05-04 09:05:46.317374', '2023-05-04 09:05:46.317374', 0, null, 1, 1);
INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (2, '2023-05-04 09:38:02.443589', '2023-05-04 09:38:02.443589', 0, null, 2, 2);
INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (3, '2023-05-04 09:44:48.347000', '2023-05-04 09:44:48.347325', 0, null, 3, 3);
INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (4, '2023-05-04 09:44:48.347000', '2023-05-04 09:44:48.347325', 0, null, 1, 6);
INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (10, '2023-05-11 10:14:16', '2023-05-11 10:14:17', 0, null, 1, 4);
INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (12, '2023-05-11 10:14:19', '2023-05-11 10:14:20', 0, null, 1, 7);
INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (13, '2023-05-11 10:14:22', '2023-05-11 10:14:22', 1, '2023-05-11 10:57:20.167983', 1, 8);
INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (14, '2023-05-11 10:14:27', '2023-05-11 10:14:28', 1, '2023-05-18 13:47:03', 1, 9);
INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (15, '2023-05-11 10:14:28', '2023-05-11 10:14:30', 0, null, 1, 10);
INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (16, '2023-05-12 14:09:15.914437', '2023-05-12 14:09:15.914437', 1, '2023-05-18 17:01:14', 1, 11);
INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (17, '2023-05-12 14:50:20.761554', '2023-05-12 14:50:20.761554', 0, null, 6, 12);
INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (18, '2023-05-12 14:52:16.702324', '2023-05-12 14:52:16.702324', 1, '2023-05-14 23:46:02', 6, 13);
INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (19, '2023-05-15 23:02:25.919142', '2023-05-15 23:02:25.919142', 0, null, 1, 14);
INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (20, '2023-05-16 12:54:38.530866', '2023-05-16 12:54:38.530866', 1, '2023-05-18 03:29:53', 1, 8);
INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (21, '2023-05-18 12:22:43.578256', '2023-05-18 12:22:43.578256', 0, null, 7, 17);
INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (22, '2023-05-18 13:30:13.438868', '2023-05-18 13:30:13.438868', 1, '2023-05-18 04:37:29', 1, 18);
INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (23, '2023-05-18 13:39:59.613263', '2023-05-18 13:39:59.613263', 0, null, 1, 18);
INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (24, '2023-05-19 01:38:30.593572', '2023-05-19 01:38:30.593572', 1, '2023-05-18 16:38:39', 6, 16);
INSERT INTO hikingdom.club_member (id, created_at, modified_at, is_withdraw, withdraw_at, club_id, member_id) VALUES (25, '2023-05-19 01:39:47.008187', '2023-05-19 01:39:47.008187', 0, null, 6, 16);
