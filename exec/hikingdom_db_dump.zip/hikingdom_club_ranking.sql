create table club_ranking
(
    id                   bigint unsigned auto_increment
        primary key,
    participation_rate   double       default 0   not null,
    ranking              bigint unsigned          not null,
    score                bigint unsigned          not null,
    set_date             date                     not null,
    total_alt            int unsigned default '0' not null,
    total_distance       int unsigned default '0' not null,
    total_duration       int unsigned default '0' not null,
    total_hiking_count   int unsigned default '0' not null,
    total_mountain_count int unsigned default '0' not null,
    club_id              bigint unsigned          not null
);

INSERT INTO hikingdom.club_ranking (id, ranking, score, set_date, total_asset_count, total_meetup_count, total_member_count, total_mountain_count, club_id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count) VALUES (1, 1, 0, '2023-05-17', 0, 0, 5, 0, 1, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_ranking (id, ranking, score, set_date, total_asset_count, total_meetup_count, total_member_count, total_mountain_count, club_id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count) VALUES (2, 1, 0, '2023-05-17', 0, 0, 1, 0, 2, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_ranking (id, ranking, score, set_date, total_asset_count, total_meetup_count, total_member_count, total_mountain_count, club_id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count) VALUES (3, 1, 0, '2023-05-17', 0, 0, 1, 0, 3, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_ranking (id, ranking, score, set_date, total_asset_count, total_meetup_count, total_member_count, total_mountain_count, club_id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count) VALUES (4, 1, 0, '2023-05-17', 0, 0, 1, 0, 5, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_ranking (id, ranking, score, set_date, total_asset_count, total_meetup_count, total_member_count, total_mountain_count, club_id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count) VALUES (5, 1, 0, '2023-05-17', 0, 0, 2, 0, 6, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_ranking (id, ranking, score, set_date, total_asset_count, total_meetup_count, total_member_count, total_mountain_count, club_id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count) VALUES (11, 1, 777, '2023-05-18', 22, 22, 9, 8, 1, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_ranking (id, ranking, score, set_date, total_asset_count, total_meetup_count, total_member_count, total_mountain_count, club_id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count) VALUES (12, 2, 543, '2023-05-18', 7, 14, 1, 5, 3, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_ranking (id, ranking, score, set_date, total_asset_count, total_meetup_count, total_member_count, total_mountain_count, club_id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count) VALUES (13, 3, 342, '2023-05-18', 7, 9, 2, 5, 6, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_ranking (id, ranking, score, set_date, total_asset_count, total_meetup_count, total_member_count, total_mountain_count, club_id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count) VALUES (14, 4, 223, '2023-05-18', 4, 4, 1, 4, 5, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_ranking (id, ranking, score, set_date, total_asset_count, total_meetup_count, total_member_count, total_mountain_count, club_id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count) VALUES (15, 5, 143, '2023-05-18', 5, 5, 1, 5, 7, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_ranking (id, ranking, score, set_date, total_asset_count, total_meetup_count, total_member_count, total_mountain_count, club_id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count) VALUES (16, 6, 122, '2023-05-18', 3, 3, 1, 3, 2, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_ranking (id, ranking, score, set_date, total_asset_count, total_meetup_count, total_member_count, total_mountain_count, club_id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count) VALUES (17, 1, 777, '2023-05-19', 22, 22, 9, 8, 1, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_ranking (id, ranking, score, set_date, total_asset_count, total_meetup_count, total_member_count, total_mountain_count, club_id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count) VALUES (18, 2, 543, '2023-05-19', 7, 14, 1, 5, 3, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_ranking (id, ranking, score, set_date, total_asset_count, total_meetup_count, total_member_count, total_mountain_count, club_id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count) VALUES (19, 3, 342, '2023-05-19', 7, 9, 2, 5, 6, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_ranking (id, ranking, score, set_date, total_asset_count, total_meetup_count, total_member_count, total_mountain_count, club_id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count) VALUES (20, 4, 223, '2023-05-19', 4, 4, 1, 4, 5, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_ranking (id, ranking, score, set_date, total_asset_count, total_meetup_count, total_member_count, total_mountain_count, club_id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count) VALUES (21, 5, 143, '2023-05-19', 5, 5, 1, 5, 7, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.club_ranking (id, ranking, score, set_date, total_asset_count, total_meetup_count, total_member_count, total_mountain_count, club_id, participation_rate, total_alt, total_distance, total_duration, total_hiking_count) VALUES (22, 6, 122, '2023-05-19', 3, 3, 1, 3, 2, 0, 0, 0, 0, 0);
