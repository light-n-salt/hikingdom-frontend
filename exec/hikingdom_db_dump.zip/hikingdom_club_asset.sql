create table club_asset
(
    id          bigint unsigned auto_increment
        primary key,
    created_at  datetime(6)       null,
    modified_at datetime(6)       null,
    col_index   smallint unsigned not null,
    row_index   smallint unsigned not null,
    asset_id    bigint unsigned   not null,
    club_id     bigint unsigned   not null,
    meetup_id   bigint unsigned   not null
);

INSERT INTO hikingdom.club_asset (id, created_at, modified_at, col_index, row_index, asset_id, club_id, meetup_id) VALUES (17, '2023-05-19 03:35:27.835302', '2023-05-19 03:35:27.835302', 0, 0, 1, 6, 28);
INSERT INTO hikingdom.club_asset (id, created_at, modified_at, col_index, row_index, asset_id, club_id, meetup_id) VALUES (19, '2023-05-19 03:35:27.835302', '2023-05-19 03:35:27.835302', 0, 0, 5, 1, 1);
INSERT INTO hikingdom.club_asset (id, created_at, modified_at, col_index, row_index, asset_id, club_id, meetup_id) VALUES (20, '2023-05-19 03:35:27.835302', '2023-05-19 03:35:27.835302', 0, 0, 44, 1, 3);
INSERT INTO hikingdom.club_asset (id, created_at, modified_at, col_index, row_index, asset_id, club_id, meetup_id) VALUES (21, '2023-05-19 03:35:27.835302', '2023-05-19 03:35:27.835302', 0, 0, 45, 1, 4);
INSERT INTO hikingdom.club_asset (id, created_at, modified_at, col_index, row_index, asset_id, club_id, meetup_id) VALUES (22, '2023-05-19 03:35:27.835302', '2023-05-19 03:35:27.835302', 0, 0, 47, 1, 5);
INSERT INTO hikingdom.club_asset (id, created_at, modified_at, col_index, row_index, asset_id, club_id, meetup_id) VALUES (23, '2023-05-19 03:35:27.835302', '2023-05-19 03:35:27.835302', 0, 0, 48, 1, 6);
INSERT INTO hikingdom.club_asset (id, created_at, modified_at, col_index, row_index, asset_id, club_id, meetup_id) VALUES (24, '2023-05-19 03:35:27.835302', '2023-05-19 03:35:27.835302', 0, 0, 49, 1, 7);
INSERT INTO hikingdom.club_asset (id, created_at, modified_at, col_index, row_index, asset_id, club_id, meetup_id) VALUES (25, '2023-05-19 03:35:27.835302', '2023-05-19 03:35:27.835302', 0, 0, 50, 1, 8);
